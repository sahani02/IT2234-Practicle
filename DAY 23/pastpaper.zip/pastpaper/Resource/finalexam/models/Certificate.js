const mongoose = require('mongoose');

const CertificateSchema = new mongoose.Schema({
  student: { type: String, ref: 'student', required: true },
  event: { type: String, ref: 'event', required: true },
  _id: { type: String, required: true },
  detail: { type: String, required: true },
  issued_date: { type: Date, required: true }
  });

module.exports = mongoose.model('cerificate', CertificateSchema);

