const express = require('express');
const app =express();
const port=3000;
const mongoose = require('mongoose')

const studentrt= require('./routes/studentRoute')
const eventrt= require('./routes/eventRoute')
const certificatert= require('./routes/certificateRoute')


app.use(express.json())
app.use('/stu',studentrt)
app.use('/eve',eventrt)
app.use('/cer',certificatert)


mongoose.connect('mongodb://localhost:27017/verificationDB').then(()=>{
    console.log("Database connected")
}).catch((error)=>{
    console.error(error);   
})

app.listen(port,()=>{
    console.log(`Server is running on ${port}`);
})