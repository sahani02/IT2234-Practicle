const express=require('express')
const router = express.Router()
const Student=require('../models/Student')
const service = require('../services/genericFindService')

router.get('/', async (req,res)=>{
    service.findFun(res,Student)
})


module.exports=router