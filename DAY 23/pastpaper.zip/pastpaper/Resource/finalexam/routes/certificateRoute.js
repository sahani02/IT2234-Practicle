const express=require('express')
const router = express.Router()
const Certificate=require('../models/Certificate')
const service = require('../services/genericFindService')

router.get('/', async (req,res)=>{
    service.findFun(res,Certificate)
})


module.exports=router