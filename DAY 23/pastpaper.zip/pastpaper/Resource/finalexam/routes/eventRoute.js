const express=require('express')
const router = express.Router()
const Event=require('../models/Event')
const service = require('../services/genericFindService')

router.get('/', async (req,res)=>{
    service.findFun(res,Event)
})


module.exports=router