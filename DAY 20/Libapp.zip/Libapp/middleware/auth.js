const User=require('../models/User')
const secretkey="vau.phy@2025"
const jwt=require("jsonwebtoken")

/*function verifyToken(req,res,next){
    try{
        const token=req.headers.authorization
        if(!token){
            return res.status(403).send("sequrity Token not Available!")
        }
        //decryption
        jwt.verify(token.split(" ")[1],secretkey,async(err,decoded)=>{
            const userName=decoded.NAME
            const user=await User.findOne({userName})
            if(!user){
                return res.sataus(401).send("Invalid Token !")
            }
            next()
        })
    }catch(error){
        console.error(error);
        res.status(500).send("Server error! ")
    }
}*/

function verifyToken(req,res,next){
    try{
        const token=req.headers.authorization
        if(!token){
            return res.status(403).send("sequrity Token not Available!")
        }
        //decryption
        jwt.verify(token.split(" ")[1],secretkey,async(err,decoded)=>{
        if(!decoded){
            return res.status(401).send("Invalid Token !")
        }
            const userID=decoded.ID
            const user=await User.findById(userID)
            if(!user || err){
                return res.sataus(401).send("Invalid Token !")
            }
            next()
        })
    }catch(error){
        console.error(error);
        res.status(500).send("Server error! ")
    }
}
module.exports={verifyToken}